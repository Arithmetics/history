--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.5
-- Dumped by pg_dump version 11.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE history_development;
--
-- Name: history_development; Type: DATABASE; Schema: -; Owner: brocktillotson
--

CREATE DATABASE history_development WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE history_development OWNER TO brocktillotson;

\connect history_development

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: brocktillotson
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.ar_internal_metadata OWNER TO brocktillotson;

--
-- Name: fantasy_games; Type: TABLE; Schema: public; Owner: brocktillotson
--

CREATE TABLE public.fantasy_games (
    id bigint NOT NULL,
    year integer,
    week integer,
    away_fantasy_team_id bigint,
    home_fantasy_team_id bigint,
    away_score double precision,
    home_score double precision,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.fantasy_games OWNER TO brocktillotson;

--
-- Name: fantasy_games_id_seq; Type: SEQUENCE; Schema: public; Owner: brocktillotson
--

CREATE SEQUENCE public.fantasy_games_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fantasy_games_id_seq OWNER TO brocktillotson;

--
-- Name: fantasy_games_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: brocktillotson
--

ALTER SEQUENCE public.fantasy_games_id_seq OWNED BY public.fantasy_games.id;


--
-- Name: fantasy_starts; Type: TABLE; Schema: public; Owner: brocktillotson
--

CREATE TABLE public.fantasy_starts (
    id bigint NOT NULL,
    points double precision,
    fantasy_team_id bigint NOT NULL,
    player_id bigint NOT NULL,
    year integer,
    week integer,
    "position" character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.fantasy_starts OWNER TO brocktillotson;

--
-- Name: fantasy_starts_id_seq; Type: SEQUENCE; Schema: public; Owner: brocktillotson
--

CREATE SEQUENCE public.fantasy_starts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fantasy_starts_id_seq OWNER TO brocktillotson;

--
-- Name: fantasy_starts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: brocktillotson
--

ALTER SEQUENCE public.fantasy_starts_id_seq OWNED BY public.fantasy_starts.id;


--
-- Name: fantasy_teams; Type: TABLE; Schema: public; Owner: brocktillotson
--

CREATE TABLE public.fantasy_teams (
    id bigint NOT NULL,
    name character varying,
    year integer,
    owner_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.fantasy_teams OWNER TO brocktillotson;

--
-- Name: fantasy_teams_id_seq; Type: SEQUENCE; Schema: public; Owner: brocktillotson
--

CREATE SEQUENCE public.fantasy_teams_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fantasy_teams_id_seq OWNER TO brocktillotson;

--
-- Name: fantasy_teams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: brocktillotson
--

ALTER SEQUENCE public.fantasy_teams_id_seq OWNED BY public.fantasy_teams.id;


--
-- Name: owners; Type: TABLE; Schema: public; Owner: brocktillotson
--

CREATE TABLE public.owners (
    id bigint NOT NULL,
    name character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.owners OWNER TO brocktillotson;

--
-- Name: owners_id_seq; Type: SEQUENCE; Schema: public; Owner: brocktillotson
--

CREATE SEQUENCE public.owners_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.owners_id_seq OWNER TO brocktillotson;

--
-- Name: owners_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: brocktillotson
--

ALTER SEQUENCE public.owners_id_seq OWNED BY public.owners.id;


--
-- Name: players; Type: TABLE; Schema: public; Owner: brocktillotson
--

CREATE TABLE public.players (
    id bigint NOT NULL,
    name character varying,
    birthdate date,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    picture_id character varying
);


ALTER TABLE public.players OWNER TO brocktillotson;

--
-- Name: players_id_seq; Type: SEQUENCE; Schema: public; Owner: brocktillotson
--

CREATE SEQUENCE public.players_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.players_id_seq OWNER TO brocktillotson;

--
-- Name: players_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: brocktillotson
--

ALTER SEQUENCE public.players_id_seq OWNED BY public.players.id;


--
-- Name: purchases; Type: TABLE; Schema: public; Owner: brocktillotson
--

CREATE TABLE public.purchases (
    id bigint NOT NULL,
    "position" character varying,
    year integer,
    fantasy_team_id bigint NOT NULL,
    player_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    price integer
);


ALTER TABLE public.purchases OWNER TO brocktillotson;

--
-- Name: purchases_id_seq; Type: SEQUENCE; Schema: public; Owner: brocktillotson
--

CREATE SEQUENCE public.purchases_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchases_id_seq OWNER TO brocktillotson;

--
-- Name: purchases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: brocktillotson
--

ALTER SEQUENCE public.purchases_id_seq OWNED BY public.purchases.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: brocktillotson
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO brocktillotson;

--
-- Name: season_stats; Type: TABLE; Schema: public; Owner: brocktillotson
--

CREATE TABLE public.season_stats (
    id bigint NOT NULL,
    year integer,
    games_played integer,
    passing_completions integer,
    passing_attempts integer,
    passing_yards integer,
    passing_touchdowns integer,
    interceptions integer,
    rushing_attempts integer,
    rushing_yards integer,
    rushing_touchdowns integer,
    receiving_yards integer,
    receptions integer,
    receiving_touchdowns integer,
    fumbles_lost integer,
    age_at_season double precision,
    experience_at_season integer,
    player_id bigint,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    "position" character varying,
    rank_reg integer,
    rank_ppr integer,
    fantasy_points_reg double precision,
    fantasy_points_ppr double precision
);


ALTER TABLE public.season_stats OWNER TO brocktillotson;

--
-- Name: season_stats_id_seq; Type: SEQUENCE; Schema: public; Owner: brocktillotson
--

CREATE SEQUENCE public.season_stats_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.season_stats_id_seq OWNER TO brocktillotson;

--
-- Name: season_stats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: brocktillotson
--

ALTER SEQUENCE public.season_stats_id_seq OWNED BY public.season_stats.id;


--
-- Name: fantasy_games id; Type: DEFAULT; Schema: public; Owner: brocktillotson
--

ALTER TABLE ONLY public.fantasy_games ALTER COLUMN id SET DEFAULT nextval('public.fantasy_games_id_seq'::regclass);


--
-- Name: fantasy_starts id; Type: DEFAULT; Schema: public; Owner: brocktillotson
--

ALTER TABLE ONLY public.fantasy_starts ALTER COLUMN id SET DEFAULT nextval('public.fantasy_starts_id_seq'::regclass);


--
-- Name: fantasy_teams id; Type: DEFAULT; Schema: public; Owner: brocktillotson
--

ALTER TABLE ONLY public.fantasy_teams ALTER COLUMN id SET DEFAULT nextval('public.fantasy_teams_id_seq'::regclass);


--
-- Name: owners id; Type: DEFAULT; Schema: public; Owner: brocktillotson
--

ALTER TABLE ONLY public.owners ALTER COLUMN id SET DEFAULT nextval('public.owners_id_seq'::regclass);


--
-- Name: players id; Type: DEFAULT; Schema: public; Owner: brocktillotson
--

ALTER TABLE ONLY public.players ALTER COLUMN id SET DEFAULT nextval('public.players_id_seq'::regclass);


--
-- Name: purchases id; Type: DEFAULT; Schema: public; Owner: brocktillotson
--

ALTER TABLE ONLY public.purchases ALTER COLUMN id SET DEFAULT nextval('public.purchases_id_seq'::regclass);


--
-- Name: season_stats id; Type: DEFAULT; Schema: public; Owner: brocktillotson
--

ALTER TABLE ONLY public.season_stats ALTER COLUMN id SET DEFAULT nextval('public.season_stats_id_seq'::regclass);


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: brocktillotson
--

COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
\.
COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM '$$PATH$$/3267.dat';

--
-- Data for Name: fantasy_games; Type: TABLE DATA; Schema: public; Owner: brocktillotson
--

COPY public.fantasy_games (id, year, week, away_fantasy_team_id, home_fantasy_team_id, away_score, home_score, created_at, updated_at) FROM stdin;
\.
COPY public.fantasy_games (id, year, week, away_fantasy_team_id, home_fantasy_team_id, away_score, home_score, created_at, updated_at) FROM '$$PATH$$/3253.dat';

--
-- Data for Name: fantasy_starts; Type: TABLE DATA; Schema: public; Owner: brocktillotson
--

COPY public.fantasy_starts (id, points, fantasy_team_id, player_id, year, week, "position", created_at, updated_at) FROM stdin;
\.
COPY public.fantasy_starts (id, points, fantasy_team_id, player_id, year, week, "position", created_at, updated_at) FROM '$$PATH$$/3255.dat';

--
-- Data for Name: fantasy_teams; Type: TABLE DATA; Schema: public; Owner: brocktillotson
--

COPY public.fantasy_teams (id, name, year, owner_id, created_at, updated_at) FROM stdin;
\.
COPY public.fantasy_teams (id, name, year, owner_id, created_at, updated_at) FROM '$$PATH$$/3257.dat';

--
-- Data for Name: owners; Type: TABLE DATA; Schema: public; Owner: brocktillotson
--

COPY public.owners (id, name, created_at, updated_at) FROM stdin;
\.
COPY public.owners (id, name, created_at, updated_at) FROM '$$PATH$$/3259.dat';

--
-- Data for Name: players; Type: TABLE DATA; Schema: public; Owner: brocktillotson
--

COPY public.players (id, name, birthdate, created_at, updated_at, picture_id) FROM stdin;
\.
COPY public.players (id, name, birthdate, created_at, updated_at, picture_id) FROM '$$PATH$$/3261.dat';

--
-- Data for Name: purchases; Type: TABLE DATA; Schema: public; Owner: brocktillotson
--

COPY public.purchases (id, "position", year, fantasy_team_id, player_id, created_at, updated_at, price) FROM stdin;
\.
COPY public.purchases (id, "position", year, fantasy_team_id, player_id, created_at, updated_at, price) FROM '$$PATH$$/3263.dat';

--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: brocktillotson
--

COPY public.schema_migrations (version) FROM stdin;
\.
COPY public.schema_migrations (version) FROM '$$PATH$$/3266.dat';

--
-- Data for Name: season_stats; Type: TABLE DATA; Schema: public; Owner: brocktillotson
--

COPY public.season_stats (id, year, games_played, passing_completions, passing_attempts, passing_yards, passing_touchdowns, interceptions, rushing_attempts, rushing_yards, rushing_touchdowns, receiving_yards, receptions, receiving_touchdowns, fumbles_lost, age_at_season, experience_at_season, player_id, created_at, updated_at, "position", rank_reg, rank_ppr, fantasy_points_reg, fantasy_points_ppr) FROM stdin;
\.
COPY public.season_stats (id, year, games_played, passing_completions, passing_attempts, passing_yards, passing_touchdowns, interceptions, rushing_attempts, rushing_yards, rushing_touchdowns, receiving_yards, receptions, receiving_touchdowns, fumbles_lost, age_at_season, experience_at_season, player_id, created_at, updated_at, "position", rank_reg, rank_ppr, fantasy_points_reg, fantasy_points_ppr) FROM '$$PATH$$/3265.dat';

--
-- Name: fantasy_games_id_seq; Type: SEQUENCE SET; Schema: public; Owner: brocktillotson
--

SELECT pg_catalog.setval('public.fantasy_games_id_seq', 664, true);


--
-- Name: fantasy_starts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: brocktillotson
--

SELECT pg_catalog.setval('public.fantasy_starts_id_seq', 23359, true);


--
-- Name: fantasy_teams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: brocktillotson
--

SELECT pg_catalog.setval('public.fantasy_teams_id_seq', 125, true);


--
-- Name: owners_id_seq; Type: SEQUENCE SET; Schema: public; Owner: brocktillotson
--

SELECT pg_catalog.setval('public.owners_id_seq', 17, true);


--
-- Name: players_id_seq; Type: SEQUENCE SET; Schema: public; Owner: brocktillotson
--

SELECT pg_catalog.setval('public.players_id_seq', 1, false);


--
-- Name: purchases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: brocktillotson
--

SELECT pg_catalog.setval('public.purchases_id_seq', 1173, true);


--
-- Name: season_stats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: brocktillotson
--

SELECT pg_catalog.setval('public.season_stats_id_seq', 3875, true);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: brocktillotson
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: fantasy_games fantasy_games_pkey; Type: CONSTRAINT; Schema: public; Owner: brocktillotson
--

ALTER TABLE ONLY public.fantasy_games
    ADD CONSTRAINT fantasy_games_pkey PRIMARY KEY (id);


--
-- Name: fantasy_starts fantasy_starts_pkey; Type: CONSTRAINT; Schema: public; Owner: brocktillotson
--

ALTER TABLE ONLY public.fantasy_starts
    ADD CONSTRAINT fantasy_starts_pkey PRIMARY KEY (id);


--
-- Name: fantasy_teams fantasy_teams_pkey; Type: CONSTRAINT; Schema: public; Owner: brocktillotson
--

ALTER TABLE ONLY public.fantasy_teams
    ADD CONSTRAINT fantasy_teams_pkey PRIMARY KEY (id);


--
-- Name: owners owners_pkey; Type: CONSTRAINT; Schema: public; Owner: brocktillotson
--

ALTER TABLE ONLY public.owners
    ADD CONSTRAINT owners_pkey PRIMARY KEY (id);


--
-- Name: players players_pkey; Type: CONSTRAINT; Schema: public; Owner: brocktillotson
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_pkey PRIMARY KEY (id);


--
-- Name: purchases purchases_pkey; Type: CONSTRAINT; Schema: public; Owner: brocktillotson
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: brocktillotson
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: season_stats season_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: brocktillotson
--

ALTER TABLE ONLY public.season_stats
    ADD CONSTRAINT season_stats_pkey PRIMARY KEY (id);


--
-- Name: index_fantasy_games_on_away_fantasy_team_id; Type: INDEX; Schema: public; Owner: brocktillotson
--

CREATE INDEX index_fantasy_games_on_away_fantasy_team_id ON public.fantasy_games USING btree (away_fantasy_team_id);


--
-- Name: index_fantasy_games_on_home_fantasy_team_id; Type: INDEX; Schema: public; Owner: brocktillotson
--

CREATE INDEX index_fantasy_games_on_home_fantasy_team_id ON public.fantasy_games USING btree (home_fantasy_team_id);


--
-- Name: index_fantasy_starts_on_fantasy_team_id; Type: INDEX; Schema: public; Owner: brocktillotson
--

CREATE INDEX index_fantasy_starts_on_fantasy_team_id ON public.fantasy_starts USING btree (fantasy_team_id);


--
-- Name: index_fantasy_starts_on_player_id; Type: INDEX; Schema: public; Owner: brocktillotson
--

CREATE INDEX index_fantasy_starts_on_player_id ON public.fantasy_starts USING btree (player_id);


--
-- Name: index_fantasy_teams_on_owner_id; Type: INDEX; Schema: public; Owner: brocktillotson
--

CREATE INDEX index_fantasy_teams_on_owner_id ON public.fantasy_teams USING btree (owner_id);


--
-- Name: index_owners_on_name; Type: INDEX; Schema: public; Owner: brocktillotson
--

CREATE UNIQUE INDEX index_owners_on_name ON public.owners USING btree (name);


--
-- Name: index_purchases_on_fantasy_team_id; Type: INDEX; Schema: public; Owner: brocktillotson
--

CREATE INDEX index_purchases_on_fantasy_team_id ON public.purchases USING btree (fantasy_team_id);


--
-- Name: index_purchases_on_player_id; Type: INDEX; Schema: public; Owner: brocktillotson
--

CREATE INDEX index_purchases_on_player_id ON public.purchases USING btree (player_id);


--
-- Name: index_season_stats_on_player_id; Type: INDEX; Schema: public; Owner: brocktillotson
--

CREATE INDEX index_season_stats_on_player_id ON public.season_stats USING btree (player_id);


--
-- Name: fantasy_starts fk_rails_1fa11082c6; Type: FK CONSTRAINT; Schema: public; Owner: brocktillotson
--

ALTER TABLE ONLY public.fantasy_starts
    ADD CONSTRAINT fk_rails_1fa11082c6 FOREIGN KEY (player_id) REFERENCES public.players(id);


--
-- Name: season_stats fk_rails_4fb569e70f; Type: FK CONSTRAINT; Schema: public; Owner: brocktillotson
--

ALTER TABLE ONLY public.season_stats
    ADD CONSTRAINT fk_rails_4fb569e70f FOREIGN KEY (player_id) REFERENCES public.players(id);


--
-- Name: purchases fk_rails_643a15baba; Type: FK CONSTRAINT; Schema: public; Owner: brocktillotson
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT fk_rails_643a15baba FOREIGN KEY (fantasy_team_id) REFERENCES public.fantasy_teams(id);


--
-- Name: fantasy_games fk_rails_886509bf3d; Type: FK CONSTRAINT; Schema: public; Owner: brocktillotson
--

ALTER TABLE ONLY public.fantasy_games
    ADD CONSTRAINT fk_rails_886509bf3d FOREIGN KEY (home_fantasy_team_id) REFERENCES public.fantasy_teams(id);


--
-- Name: fantasy_teams fk_rails_ad8aea69ce; Type: FK CONSTRAINT; Schema: public; Owner: brocktillotson
--

ALTER TABLE ONLY public.fantasy_teams
    ADD CONSTRAINT fk_rails_ad8aea69ce FOREIGN KEY (owner_id) REFERENCES public.owners(id);


--
-- Name: purchases fk_rails_b56fb14819; Type: FK CONSTRAINT; Schema: public; Owner: brocktillotson
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT fk_rails_b56fb14819 FOREIGN KEY (player_id) REFERENCES public.players(id);


--
-- Name: fantasy_games fk_rails_cdb8ad6a0c; Type: FK CONSTRAINT; Schema: public; Owner: brocktillotson
--

ALTER TABLE ONLY public.fantasy_games
    ADD CONSTRAINT fk_rails_cdb8ad6a0c FOREIGN KEY (away_fantasy_team_id) REFERENCES public.fantasy_teams(id);


--
-- Name: fantasy_starts fk_rails_dbcba6b1c9; Type: FK CONSTRAINT; Schema: public; Owner: brocktillotson
--

ALTER TABLE ONLY public.fantasy_starts
    ADD CONSTRAINT fk_rails_dbcba6b1c9 FOREIGN KEY (fantasy_team_id) REFERENCES public.fantasy_teams(id);


--
-- PostgreSQL database dump complete
--

